const menu=document.querySelector('.menu');
const navLinks=document.querySelector('nav ul');
menu.addEventListener('click',()=>{navLinks.classList.toggle('active')});